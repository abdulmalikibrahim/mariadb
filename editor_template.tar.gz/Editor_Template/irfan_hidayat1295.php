<!-- Note:
1 lembar total 36 voucher Normal scale 100
Setting Kertas:
Kertas : F4 di kostum ukurannya di Printing Preferences - Paper/Quality - Costum ==> width 8.50 inch - height 13.00 inch
Margin: Minimum / disesuaikan
Scale: 100 (semakin kecil semakin banyak) -->



<!-- MULAI -->
<style>
.qrcode{
	height:32px;
	width:32px;
}
</style> 
<div style="overflow:hidden;position:relative;padding: 0px;margin: 2px;border: 1px solid #FFF3E0;width:190px;height:125px;float:left;-webkit-print-color-adjust: exact;">
<div style="height:20px;">
<div style="float:left;width:45%;">
<img style="margin:5px 0 0 5px;width:90%;" src="<?php echo $logo ?>" alt="logo">
</div>
<div style="float:right;width:5%;text-align:right;font-size:8px;color:#666; margin-right:5px;">
<?php echo " [$num]";?>
</div>
<div style="float:right;width:50%;text-align:right;font-weight:bold;font-family:Agency FB;color:#555;font-size:32px;">
<small style="font-size:10px;margin-left:-17px;position:absolute;"><?= explode(" ",$price)[0]?></small><?= explode(" ",$price)[1]?>
</div>
</div>
<div style="height:75px;">
<div style="float:left;width:50%;">
<!-- Username = Password    -->
<?php if($v_opsi == "voucher"){?>
<div style="padding:0px;border-top:1px solid #777;text-align:center;font-weight:bold;font-size:10px;font-family:Courier New;">VOUCHER</div>
<div style="padding:0px;border-top:1px solid #777;border-bottom:1px solid #777;text-align:center;font-weight:bold;font-size:16px;font-family:Courier New;"><?php echo $username;?></div>
<!-- /  -->
<!-- Username & Password  -->
<?php }elseif($v_opsi == "up"){?>
<div style="padding:0px;border-top:1px solid #777;text-align:center;font-weight:bold;font-size:10px;font-family:Courier New;">MEMBER</div>
<div style="padding:0px;border-top:1px solid #777;border-bottom:1px solid #777;text-align:left;font-weight:bold;font-size:16px;font-family:Courier New;"><small>Us:</small><?php echo $username;?></div>
<div style="padding:0px;border-bottom:1px solid #777;text-align:left;font-weight:bold;font-size:16px;font-family:Courier New;"><small>Ps:</small><?php echo $password;?></div>
<?php }?>
<!-- /  -->

</div>
<div style="float:right;width:50%; position:absolute; bottom:0; right:0;">

<div style="padding:0 2.5px;text-align:right;font-size:9px;font-weight:bold;color:#333333;">
<?php
if(substr($validity,-1) == "d"){
	$validity = "Aktif ".substr($validity,0,-1)." Hari";
}else if(substr($validity,-1) == "h"){
	$validity = "Aktif ".substr($validity,0,-1)." Jam";
}
if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
	$timelimit = "Durasi : ".((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
}else if(substr($timelimit,-1) == "d"){
	$timelimit = "Durasi : ".substr($timelimit,0,-1)." HARI";
}else if(substr($timelimit,-1) == "h"){
	$timelimit = "Durasi : ".substr($timelimit,0,-1)."Jam";
}else if(substr($timelimit,-1) == "w"){
	$timelimit = "Durasi : ".(substr($timelimit,0,-1)*7)." HARI";
}
//CREATE QRCODE
$urilogin = "http://$dnsname/login?username=$username&password=$password";
$qrcode = "
	<canvas class='qrcode' id='".$uid."'></canvas>
	<script>
	(function() {
		var ".$uid." = new QRious({
			element: document.getElementById('".$uid."'),
			value: '".$urilogin."',
		});

	})();
</script>";
?>
<div style="text-transform: uppercase; font-size:5pt !important;"><?= str_replace("-","",$validity); ?></div>
<div style="text-transform: uppercase; font-size:5pt !important;"><?= $timelimit; ?></div>
<div style="padding:0 2.5px;text-align:right;font-size:8px;font-weight:bold;color:#bf0000;">Kuota <?php if(empty($datalimit)){;?>Unlimted <?php }else{ echo $datalimit;}?></div>
</div>
<div style="margin-right:5px;padding:1px;text-align:right;width:60%;float:right;">
	<?php echo $qrcode ?>
</div>

</div>
</div>
<div style="height:25px;background:#bf0000;color:#fff;font-size:9px;font-weight:bold;margin:0px;padding:2.5px;">
<div style="width:50%; position:absolute; bottom:2px; left:2px;">
cek status/logout: http://<?php echo $dnsname;?>
</div>
</div>
</div> 	            	          	            	          	            	          	            	     <!-- AKHIR -->