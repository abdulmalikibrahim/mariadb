<?php
   if(substr($validity,-1) == "d"){
     $validity = substr($validity,0,-1)." HARI";
   }else if(substr($validity,-1) == "h"){
     $validity = substr($validity,0,-1)." JAM";
   }
   if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
     $timelimit = ((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
   }else if(substr($timelimit,-1) == "d"){
     $timelimit = substr($timelimit,0,-1)." HARI";
   }else if(substr($timelimit,-1) == "h"){
     $timelimit = substr($timelimit,0,-1)." JAM";
   }else if(substr($timelimit,-1) == "w"){
     $timelimit = (substr($timelimit,0,-1)*7)." HARI";
   }          	            
   ?>   
<style>
   	.qrcode{
		height:95px !important;
		width:95px !important;
		margin-top:2px !important;
		margin-left:13px !important;
	}
</style>
<style>
@page {
size: A4;
margin: 0;
}
@media print {
html, body {
width: 210mm;
height: 297mm;
margin-left: auto;
margin-right: auto;
}
}
@media screen {
html, body {
width: 800px;
}
}
body
{
padding: 20px;
margin:0;
margin-left: auto;
margin-right: auto;
font-size: 12px;
font-family: Arial, 'Arial Unicode MS', Helvetica, Sans-Serif;
}
#main-wrap {
background-color: #fff;
height: 180px;
text-align: left;
display: inline-block;
}
#main-wrap > div {
height: 180px;
}  
#main-wrap {
width: 39%;
padding-top: 10px;
padding-bottom: 10px;
}  
#inner {
background:url("https://3.bp.blogspot.com/-7CzN7S71Bak/W3rrXxt6WpI/AAAAAAAAPB8/ad8I__8yBsMCE7IekJbb6t_-yAUjKcTogCLcBGAs/s1600/q4.png") no-repeat;
width: 286px;
height: 174px;
padding: 0px; 
}  
#hotspot-name {
padding-left: 15px;
color:#fff;
font-size: 11px;
font-weight:bold;
}  
#user-pass {
padding-top: 4px;
padding-left: 10px;
font-size: 11px;
font-weight: bold;
color: #000;
margin-top: 1px;
padding-bottom: 2px;
font-weight: bold;
} 
#price {
width: 286px;
height: 25px;
padding: 0px;
color:#fff;
font-size: 14px;
font-weight:bold;
display: inline-block;
}
#kanan {
padding-top: 6px;
padding-left:5px;
text-align: center;
font-size: 12px;
font-weight:bold;
color:#fff;
}
#info {
padding-top: 12px;
padding-right:5px;
text-align: right;
font-size: 11px;
font-weight:bold;
color:#fff;
}
#kontak {
padding-top: 15px;
padding-right:5px;
text-align: right;
font-size: 11px;
font-weight:bold;
color:#fff;
}
.left-half {
color:#000;
float: left;
width: 50%;
}
.right-half {
color:#000;
float: left;
width: 50%;
}
</style>	
<!--- Salin kode di bawah ini ke kode HTML ROW -->

<div id="main-wrap"> 
<div id="inner">
<div id="price">      
<div style="padding:5px 5px 5px 10px">Rp.<?=number_format(explode(" ",$price)[1],0,"",".")?></div>
</div>
<div class="left-half">
<div id="user-pass">             
User: [ <?= $username; ?> ]<br>
Pass: [ <?= $password; ?> ]<br>
</div>
<?=$qrcode;?>
</div>
<div class="right-half">
<div id="kanan">  
<br>
BUANANET HOTSPOT<br>
</div>
<div id="info">  
<u><?= $dnsname; ?></u><br><br>
Duration: <?= $timelimit; ?><br>
Validation: <?= $validity; ?><br>
Quota: <?php if(empty($datalimit)){;?>Unlimited<?php }else{ echo "Data ".$datalimit;}?><br>
</div>
<div id="kontak">  
CP: 081328298xxx
</div>
</div>
</div>
</div>
	
	
