<?php
if(substr($validity,-1) == "d"){
$validity = "Masa aktif:".substr($validity,0,-1)."Hari";
}else if(substr($validity,-1) == "h"){
$validity = "Masa aktif:".substr($validity,0,-1)."Jam";}
if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
$timelimit = "Durasi:".((substr($timelimit,0,-1)*7) + substr($timelimit, 2,1))."Hari";
}else if(substr($timelimit,-1) == "d"){
$timelimit = "Durasi:".substr($timelimit,0,-1)."Hari";
}else if(substr($timelimit,-1) == "h"){
$timelimit = "Durasi:".substr($timelimit,0,-1)."Jam";
}else if(substr($timelimit,-1) == "w"){
$timelimit = "Durasi:".(substr($timelimit,0,-1)*7)."Hari";}
if($profile == "1Lite"){ $color = "#00FF00";}
elseif($profile == "7Lite"){ $color = "#00FF00";}
elseif($profile == "0Lite"){ $color = "#00FF00";}
elseif($profile == "0Reg"){ $color = "#FF0000";}
elseif($profile == "1Reg"){ $color = "#FF0000";}
elseif($profile == "2Reg"){ $color = "#FF0000";}
elseif($profile == "7Reg"){ $color = "#FF0000";}
elseif($profile == "1Max"){ $color = "#BF00FF";}
elseif($profile == "2Max"){ $color = "#FFFFFF";}
else{ $color = "#00FF00";}?>

<style type="text/css">
.rotate {
  vertical-align: bottom;
  text-align: center;
}
.rotate span {
  -ms-writing-mode: tb-rl;
  -webkit-writing-mode: vertical-rl;
  writing-mode: vertical-rl;
  transform: rotate(180deg);
  white-space: nowrap;
}
.qrcode{
		height:60px;
		width:60px;
}
</style>

<table class="voucher" style="width: 230px;">
  <tbody>
    <tr>
      <td class="rotate" style="font-weight: bold; border-right: 1px solid black; background-color:<?php echo $color;?>; -webkit-print-color-adjust: exact;" rowspan="4"><span><?= $price; ?></span></td>
      <!--mks-logo-->	
	  <td style="font-weight: bold" colspan="3"><img src="<?php echo $logo;?>" alt="logo" style="height:15px;"> </td>
      <?php if($qr == "yes"){?>
	<td style="" rowspan="4"><img style="" rowspan="3"><?= $qrcode ?></td>
      <?php  }else{?>
	<td style="" rowspan="4"><img style="" rowspan="3"><?= $qrcode ?></td>
	</tr>
    <tr>
      <?php if ($v_opsi == "voucher"){ ?>  
      <td style="width: 100%; font-weight: bold; font-size: 20px; text-align: center;"><?= $username; ?></td>
      <?php 
    } elseif ($usermode == "up") { ?>
      <td style="width: 100%; font-weight: bold; font-size: 15px; text-align: center;"><?= "User: " . $username . "<br>Pass: " . $password; ?></td>
      <?php 
    } 
  }?> 
<!--mks-voucher-akhir-->
<!--mks-limitasi-mulai-->	
</tr>
<tr>
<td style="font-weight: bold; font-size: 10px; color:#000000;"><?php echo $validity;?> <?php echo $timelimit;?> <?php echo $datalimit;?></td>
</tr>
<!--mks-limitasi-akhir-->
<!--mks-cs-mulai-->	
<tr>
<td colspan="4" style="font-size: 10px;">
[<?= $num ?>]Login:<?php echo $dnsname;?>
</tr>
</tbody>
</table>