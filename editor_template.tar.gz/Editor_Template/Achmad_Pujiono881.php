<?php
   if(substr($validity,-1) == "d"){
     $validity = substr($validity,0,-1)." HARI";
   }else if(substr($validity,-1) == "h"){
     $validity = substr($validity,0,-1)." JAM";
   }
   if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
     $timelimit = ((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
   }else if(substr($timelimit,-1) == "d"){
     $timelimit = substr($timelimit,0,-1)." HARI";
   }else if(substr($timelimit,-1) == "h"){
     $timelimit = substr($timelimit,0,-1)." JAM";
   }else if(substr($timelimit,-1) == "w"){
     $timelimit = (substr($timelimit,0,-1)*7)." HARI";
   }	            	            
   ?>   
<style>
   .qrcode{
   height:85px;
   width:85px;
   }
</style>
<tr>
   <td style="color:#666;border-collapse: collapse;" valign="top">
	<table class="voucher" style="border:none; width: 350px; height:200px; background: border:none; width: 350px; height:200px; background: url('https://i.pinimg.com/750x/8a/9d/2d/8a9d2d81e4212aef57bccbdcf3ed2da9.jpg') no-repeat; background-size:contain; no-repeat; background-size:contain;">
	<tbody>
		<tr>
		<td style="width:118px"valign="top" >
			<div style="clear:both;color:red;margin-top:76px;margin-bottom:10px;">
			<?php if($v_opsi=='up'){ ?>
			<?php }else{ ?>
			<div style=" margin-left:28px; ;font-weight:bold;font-size:15px;"><?php echo $username;?></div>
			<?php } ?>
			</div>
		</td>
		<td style="width:100px;text-align:left;">
		<td>
      		<div style="position:relative;">
				<div style="margin-bottom: 10px; margin-left:55px;margin-top:0px; ">
				<img style="height:35px; width:160px;" src="<?php echo $logo;?>">
				<div style="font-weight:bold;font-size:9px;color:#fff;">AKTIF : <?php echo str_replace("-","",$validity);?></div>
				<div style="font-weight:bold;font-size:9px;color:#fff;">DURASI : <?php echo str_replace("-","",$timelimit);?></div>
				<div align="center" style="position:absolute;width: 160px;background:black;font-family:cooper black;font-size:20pt;font-weight:bold;color:white;bottom: 35px;left: -128px;padding-left:5px;border-radius: 15px;"><?= number_format(explode(" ",$price)[1],0,"",".") ?></div>
				</div>
				<div style=" margin-top: 20px;margin-left: 96px;"><?= $qrcode ?></div>
				<!-- NUM -->
				<div style="margin-bottom: 10px; margin-left:195px;margin-top:5px;color:#fff;font-size:10px;padding:0px;"><?php echo " [$num]";?></div>
				<!-- NUM -->
			</div>
		</td>
		</tr>
	</tbody>
	</table>
   </td>
</tr>