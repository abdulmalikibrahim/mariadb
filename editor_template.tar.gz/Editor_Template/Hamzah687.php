<?php
   if(substr($validity,-1) == "d"){
     $validity = substr($validity,0,-1)." HARI";
   }else if(substr($validity,-1) == "h"){
     $validity = substr($validity,0,-1)." JAM";
   }
   if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
     $timelimit = ((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
   }else if(substr($timelimit,-1) == "d"){
     $timelimit = substr($timelimit,0,-1)." HARI";
   }else if(substr($timelimit,-1) == "h"){
     $timelimit = substr($timelimit,0,-1)." JAM";
   }else if(substr($timelimit,-1) == "w"){
     $timelimit = (substr($timelimit,0,-1)*7)." HARI";
   }          	            
   ?>   
<style>
   	.qrcode{
		height:65px !important;
		width:65px !important;
	}
</style>

<style>@media print{.noprint{display:none}.pagebreak{page-break-after:always}}.canvas{background-image:url(https://www.netme.id/wp-content/uploads/2019/01/voucher-hotspot-mikrotik-keren.jpg);background-color:#DFE0E1;background-size:cover;width:227px;height:151px;margin:3px 3px 3px 3px;padding:0;float:left}body{font-family:'Oswald',sans-serif}.row{width:200px;margin:3px 0 3px 3px;height:145px;float:left}.tittle{width:150px;height:35px}.tittle h5{line-height:15px;margin:0;font-size:15px;padding-left:21px;padding-top:5px;font-family:'Righteous',cursive}.tittle h5 span{color:#D9141A}.tittle p{margin:0;font-size:9px;line-height:8px;padding-left:21px}.konten{width:51%;height:75px;margin-top:35px;margin-left:4%;float:left}.konten p{margin:0;font-size:12px;line-height:11px;font-family:'Teko',sans-serif;color:#383635}.konten p .a{margin-left:2px}.konten p .b{margin-left:16px}.konten h5{margin:0;font-size:7px;line-height:8px;color:#D9141A;font-family:'Righteous',cursive;font-weight:400}.konten .footer{margin:7px 0 0 28px}.konten .footer h4{margin:0;font-size:10px;line-height:12px;color:#242323;font-weight:400}.user{width:45%;height:110px;float:left}.user h5{margin:10px 0 0 18px;font-size:10px;line-height:12px;color:#474443;font-weight:400}.user h4{width:75%;background-color:rgba(240,133,25,.3);margin:2px 0 0 10px;font-size:12px;line-height:12px;padding:1px 3px 3px 3px;color:#474443;text-align:center;border:1px solid #D9141A;border-radius:8px;letter-spacing:1px;font-weight:400}.side{width:23px;height:145px;float:left;margin-top:3px}.side p{margin-top:55px;margin-right:1px;color:#fff;font-size:17px;font-weight:700;font-family:'Coda',cursive;-webkit-transform:rotate(90deg);-moz-transform:rotate(90deg);-ms-transform:rotate(90deg);-o-transform:rotate(90deg);transform:rotate(90deg)}.qrcode{width:62px;margin-top:1px;margin-left:15px;padding:2px;background-color:#fff}</style>	
	<!--- Salin kode di bawah ini ke kode HTML ROW -->
	
	<div class="canvas">
	  <div class="row">
		<div class="tittle"><img src="<?= $logo; ?>" width="70%"></div>
		<div class="konten">
			<p>Masa Aktif <span class="a">: <?= $validity; ?></span></p>
			<p>Durasi <span class="b">: <?= $timelimit; ?></span></p>
			<h5><?php if(empty($datalimit)){;?>Nikmati internet Unlimited.... bebas quota tanpa batas!.... <?php }else{ echo "Data ".$datalimit;}?></h5>
			<div class="footer">
				<h4>Andre bahar</h4>
				<h4>0852 6655 4455</h4>
			</div>
		</div>
		<div class="user">
			<?php if($v_opsi=='voucher'){
				?>
				<h5>KODE VOUCHER</h5>
				<h4><?=$username?></h4>
				
				<?= $qrcode; ?>
				<?php
			}?>
		</div>
	  </div>
	  <div class="side"><p><?= number_format(explode(" ",$price)[1],0,"","."); ?></p></div>
	</div>