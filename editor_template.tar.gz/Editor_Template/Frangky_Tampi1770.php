<?php
if(substr($validity,-1) == "d"){
  $validity = "MASA AKTIF : ".substr($validity,0,-1)." HARI";
}else if(substr($validity,-1) == "h"){
  $validity = "MASA AKTIF : ".substr($validity,0,-1)." JAM";
}
if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
  $timelimit = "Durasi:".((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
}else if(substr($timelimit,-1) == "d"){
  $timelimit = "Durasi:".substr($timelimit,0,-1)." HARI";
}else if(substr($timelimit,-1) == "h"){
  $timelimit = "Durasi:".substr($timelimit,0,-1)."Jam";
}else if(substr($timelimit,-1) == "w"){
  $timelimit = "Durasi:".(substr($timelimit,0,-1)*7)." HARI";
}	            	            

/* 
Sesuikan harga dan warna masing-masing.
warna bisa dilihat di https://material.io/guidelines/style/color.html#color-color-palette
variable $color
background-color:<?php echo $color;?>; -webkit-print-color-adjust: exact;
ditambahkan ke style di tag html yang ingin dikasi warna. untuk template ini warna ditaruh di keterangan harga <-- Price --> line 81
*/

if($getsprice == "3000"){ $color = "#666";} // jika harga == "1000" maka warna = "#01579B"
elseif($getsprice == "1000"){ $color = "#FF1493";}
elseif($getsprice == "2000"){ $color = "#8B008B";}
elseif($getsprice == "3000"){ $color = "#666";}
elseif($getsprice == "5000"){ $color = "#FF4500";}
elseif($getsprice == "10000"){ $color = "#E65100";}
elseif($getsprice == "15000"){ $color = "#228B22";}
elseif($getsprice == "20000"){ $color = "#008000";}
elseif($getsprice == "30000"){ $color = "#FF00FF";}
elseif($getsprice == "60000"){ $color = "#E60C00";} 
elseif($getsprice == "70000"){ $color = "#FF0000";} 
// ini yang dicopy untuk menambah warna berdarsarkan harga, kemudian paste di atas baris // else color

// else color
else{ $color = "#BA68C8";}
?>  
 <!--mks-mulai-->
</style>
<table class="voucher" style=" width: 180px;">
<tbody>
    <!-- Logo Hotspotname -->
    <tr>
        <td style="text-align: center; font-size: 14px; font-weight:bold; border-bottom: 1px black solid;"><img src="<?= $logo ?>" alt="logo" style="height:30px;border:0;"><br></td>
    </tr>
    <!-- /  -->
    <tr>
        <td>
            <table style=" text-align: center; width: 170px; font-size: 12px;">
                <tbody>
                    <!-- Username Password QR    -->
                    <tr>
                        <td>
                            <table style="width:100%;">
                                <!-- Username = Password    -->
                                <?php if ($v_opsi == "voucher") { ?>
                                <tr>
                                    <td style="font-size: 12px; text-align:center;">Kode Voucher :</td>
                                </tr>
                                <tr>
                                    <td style="width:100%; border: 1px solid red; font-weight:bold; font-size:16px; text-align:center; color:#ff0000ff;"><?= $username ?></td>
                                </tr>
                                <!-- /  -->
                                <!-- Username & Password  -->
                                <?php } elseif ($v_opsi == "up") { ?>
                                <tr>
                                    <td style="width: 50%">Username</td>
                                    <td >Password</td>
                                </tr>
                                <tr style="font-size: 14px;">
                                    <td style="border: 1px solid black; font-weight:bold; text-align:center;"><?= $username ?></td>
                                    <td style="border: 1px solid black; font-weight:bold; text-align:center;"><?= $password ?></td>
                                </tr>
                                <?php } ?>
                                <!-- /  -->
                                </tr>
                                </td>
                                <!-- /  -->
                                <tr>
                                    <!-- Price  -->
                                    <td colspan="2" style="border-top: 1px solid black;font-weight:bold; font-size:12px; text-align:center;"><?= $validity ?> <?= $timelimit ?> <?= $datalimit ?><br>Pusomaen-NET</td>
                                    <!-- /  -->
                                </tr>
                                <tr>
                                   
                                </tr>
                                <!-- /  -->
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
          </tbody>
      </table>