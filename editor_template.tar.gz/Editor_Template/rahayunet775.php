<?php
   if(substr($validity,-1) == "d"){
     $validity = substr($validity,0,-1)." HARI";
   }else if(substr($validity,-1) == "h"){
     $validity = substr($validity,0,-1)." JAM";
   }
   if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
     $timelimit = ((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
   }else if(substr($timelimit,-1) == "d"){
     $timelimit = substr($timelimit,0,-1)." HARI";
   }else if(substr($timelimit,-1) == "h"){
     $timelimit = substr($timelimit,0,-1)." JAM";
   }else if(substr($timelimit,-1) == "w"){
     $timelimit = (substr($timelimit,0,-1)*7)." HARI";
   }          	            
   ?>   
<style>
   	.qrcode{
		height:65px !important;
		width:65px !important;
	}
</style>

<style>
	@media print { .noprint { display: none; } .pagebreak { page-break-after: always; } }
	.canvas {
			background-image: url("https://www.netme.id/wp-content/uploads/2019/01/mikrotik-hotspot-voucher-caffee.jpg");
			background-color: c07542;
			width: 205px;
			height: 151px;
			margin: 10px 10px 10px 10px;
			padding: 0;
			float: left;
			border-style: solid;
			border-width: 2px;
			}
	body 	{ font-family: 'Oswald', sans-serif;
			}
	.tittle	{
			background-color: #351b0c;
			height: 25px;
			text-align: center;
			font-size: 15px;
			}
	.tittle span {
			color: #ffffff;
			line-height: 25px;
			}
	.konten	{
			height: 101px;
			}
	.konten	.kt1 {
			margin-top: 20px;
			width: 55%;
			float: right;
			}
	.konten	.kt1 .user {
			color: #ffffff;
			margin: 5px 0 0 2px;
			width: 35px;
			float: left;
			}
	.konten	.kt1 .userdata {
			margin: 5px 0 0 2px;
			background: #642e0b;
			color: #cfb6a6;
			width: 65px;
			height: 25px;
			float: left;
			}
	.konten	.kt1 .userdata span {
			font-size: 15px;
			line-height: 25px;
			margin-left: 5px;
			}
	.footer	{
			height: 25px;
			text-align: center;
			font-size: 12px;
			}
	.footer span {
			color: #000000;
			line-height: 25px;
			}
</style>	
<!--- Salin kode di bawah ini ke kode HTML ROW -->

<div class="canvas">
	<div class="tittle"><span>Voucher Hotspot</span></div>
	<div class="konten">
		<div class="kt1">
			<div class="user">User : </div><div class="userdata"><span><?=$username;?></span></div>
			<div class="user">Pass : </div><div class="userdata"><span><?=$password;?></span></div>
		</div>
	</div>
	<div class="footer"><span><b>NetMe Cafe</b> Evi Hotspot | 085819520048</span></div>
</div>