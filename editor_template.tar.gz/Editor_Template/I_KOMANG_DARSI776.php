&lt;!-- Note:
1 lembar total 36 voucher Normal scale 100
Setting Kertas:
Kertas : F4 di kostum ukurannya di Printing Preferences - Paper/Quality - Costum ==> width 8.50 inch - height 13.00 inch
Margin: Minimum / disesuaikan
Scale: 100 (semakin kecil semakin banyak) --&gt;



&lt;!-- MULAI --&gt;
&lt;style&gt;
.qrcode{
 height:32px;
 width:32px;
}
&lt;/style&gt; 
<div xss=removed>
<div xss=removed>
<div xss=removed>
<img xss=removed src="&lt;?php echo $logo ?&gt;" alt="logo">
</div>
<div xss=removed>
&lt;?php echo " [$num]";?&gt;
</div>
<div xss=removed>
<small xss=removed>&lt;?= explode(" ",$price)[0]?&gt;</small>&lt;?= explode(" ",$price)[1]?&gt;
</div>
</div>
<div xss=removed>
<div xss=removed>
&lt;!-- Username = Password    --&gt;
&lt;?php if($v_opsi == "voucher"){?&gt;
<div xss=removed>VOUCHER</div>
<div xss=removed>&lt;?php echo $username;?&gt;</div>
&lt;!-- /  --&gt;
&lt;!-- Username & Password  --&gt;
&lt;?php }elseif($v_opsi == "up"){?&gt;
<div xss=removed>MEMBER</div>
<div xss=removed><small>Us:</small>&lt;?php echo $username;?&gt;</div>
<div xss=removed><small>Ps:</small>&lt;?php echo $password;?&gt;</div>
&lt;?php }?&gt;
&lt;!-- /  --&gt;

</div>
<div xss=removed>

<div xss=removed>
&lt;?php
if(substr($validity,-1) == "d"){
 $validity = "Aktif ".substr($validity,0,-1)." Hari";
}else if(substr($validity,-1) == "h"){
 $validity = "Aktif ".substr($validity,0,-1)." Jam";
}
if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
 $timelimit = "Durasi : ".((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
}else if(substr($timelimit,-1) == "d"){
 $timelimit = "Durasi : ".substr($timelimit,0,-1)." HARI";
}else if(substr($timelimit,-1) == "h"){
 $timelimit = "Durasi : ".substr($timelimit,0,-1)."Jam";
}else if(substr($timelimit,-1) == "w"){
 $timelimit = "Durasi : ".(substr($timelimit,0,-1)*7)." HARI";
}
//CREATE QRCODE
$urilogin = "http://$dnsname/login?username=$username&password=$password";
$qrcode = "
 <canvas class='qrcode' id='".$uid."'></canvas>
 [removed]
 (function() {
  var ".$uid." = new QRious({
   element: document.getElementById('".$uid."'),
   value: '".$urilogin."',
  });

 })();
[removed]";
?&gt;
<div xss=removed>Aktif 1 Hari&lt;?= str_replace("-","",$validity); ?&gt;</div>
<div xss=removed>&lt;?= $timelimit; ?&gt;</div>
<div xss=removed>Kuota &lt;?php if(empty($datalimit)){;?&gt;Unlimted &lt;?php }else{ echo $datalimit;}?&gt;</div>
</div>
<div xss=removed>
 &lt;?php echo $qrcode ?&gt;
</div>

</div>
</div>
<div xss=removed>
<div xss=removed>
cek status/logout: http://&lt;?php echo $dnsname;?&gt;
</div>
</div>
</div>                                                                                            &lt;!-- AKHIR --&gt;