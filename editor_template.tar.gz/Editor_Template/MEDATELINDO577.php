<style>table.voucher {display:inline-block;border: 1px solid black; margin: 1px; } .qrcode{ height:55px; width:55px; }</style>
<?php
$rowdatalimit = '

$rowtimelimit = '
	<tr>
		<td style="border:1px solid; font-size:8pt;" class="text-center p-0">Time Limit</td>
		<td style="border:1px solid; font-size:8pt;" class="text-center p-0"><span class="font-weight-bold" style="font-size:8pt;">'.$timelimit.'</span></td>
		<td class="text-center p-0"></td>
	</tr>';

if($v_opsi == "voucher"){
	$voucher_print = '
	<table class="w-100 m-0">
		<tr>
			<td colspan="3" class="text-center p-0" style="border:1px solid;">
				<div style="font-weight:bold; font-size:9pt;">KODE VOUCHER</div>
				<span class="font-weight-bold" style="font-size:15pt;">'.$voucher->name.'</span>
			</td>
		</tr>
		'.$rowdatalimit.$rowtimelimit.'
		<tr>
			<td style="border:1px solid; font-size:8pt;" class="text-center p-0">Validity</td>
			<td style="border:1px solid; font-size:8pt;" class="text-center p-0"><span class="font-weight-bold" style="font-size:8pt;">'.$validity.'</span></td>
			<td class="text-center p-0"></td>
		</tr>
	</table>';
}else{
	$voucher_print = '
	<table class="w-100 m-0 mb-2 mt-2" style="border:1px dark;">
		<tr>
			<td style="border:1px solid;" class="text-center p-0">Username</td>
			<td style="border:1px solid;" class="text-center p-0">Password</td>
		</tr>
		<tr>
			<td style="border:1px solid;" class="text-center p-0"><span class="font-weight-bold" style="font-size:9pt;">'.$voucher->name.'</span></td>
			<td style="border:1px solid;" class="text-center p-0"><span class="font-weight-bold" style="font-size:9pt;">'.$voucher->password.'</span></td>
		</tr>
	</table>
	<table class="w-100 m-0">
		'.$rowdatalimit.$rowtimelimit.'
		<tr>
			<td style="border:1px solid; font-size:8pt;" class="text-center p-0">Validity</td>
			<td style="border:1px solid; font-size:8pt;" class="text-center p-0"><span class="font-weight-bold" style="font-size:8pt;">'.$validity.'</span></td>
		</tr>
	</table>';
}
?>
<style>
	table.voucher {
		display: inline-block;
		border: 1px solid black;
		margin: 1px;
	}
</style>
<table class="voucher" style=" width: 190px;">
	<tbody>
		<tr>
			<td style="text-align: center; font-size: 14px; font-weight:bold; border-bottom: 1px black solid;">
				<img style="margin:5px 0 0 5px;" width="85" height="20" src="<?= $logo; ?>" alt="logo">
			</td>
		</tr>
		<tr>
			<td>
				<?= $voucher_print; ?>
				<table style=" text-align: center; width: 185px; font-size: 11px;">
					<tbody>
						<td style="border:1px solid;" class="font-weight-bold"><h4 class="m-0"><?= $harga; ?></h4></td>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>