<?php
   if(substr($validity,-1) == "d"){
     $validity = substr($validity,0,-1)." HARI";
   }else if(substr($validity,-1) == "h"){
     $validity = substr($validity,0,-1)." JAM";
   }
   if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
     $timelimit = ((substr($timelimit,0,-1)*7) +  substr($timelimit, 2,1))." HARI";
   }else if(substr($timelimit,-1) == "d"){
     $timelimit = substr($timelimit,0,-1)." HARI";
   }else if(substr($timelimit,-1) == "h"){
     $timelimit = substr($timelimit,0,-1)." JAM";
   }else if(substr($timelimit,-1) == "w"){
     $timelimit = (substr($timelimit,0,-1)*7)." HARI";
   }          	            
   ?>   
<style>
@media print {
  .noprint {
    display: none;
  }
  .pagebreak {
    page-break-after: always;
  }
}
body
{
   padding: 0;
   margin:0;
   min-width: 700px;
   color: #303F50;
   font-size: 10px;
   font-family: Arial, 'Arial Unicode MS', Helvetica, Sans-Serif;
   line-height: 85%;   
}
.mikrotikindo table, table.mikrotikindo
{
   border-collapse: collapse;
   margin: 2px;
}
.mikrotikindo th, .mikrotikindo td
{
   padding: 2px;
   border: solid 1px #FC0000;
   vertical-align: top;
   text-align: center;
}
.vertical-text {
transform: rotate(90deg);
padding: 4px;
float: right;
font-size: 15px;
margin-top: 8px;
width: 10px;
color: #FC0000;
}
  
</style>
<!--- Salin kode di bawah ini ke kode HTML ROW -->

<!-- Ini Awal ROW -->
<table class="mikrotikindo" style=" display: inline-block; background-color:#FC0000; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; width: 200px; height:120px;"> 
<tbody> 
<tr> 
<td style="width: 190px; text-align: center;">
<span style="font-weight: bold; color: rgb(255, 255, 255); font-size: 13px; font-family: Tahoma;">BTK-NETWORK</span><br> 
<table class="mikrotikindo" style="background-color:#FFF8DC; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; width: 100%; margin-right: auto; margin-left: auto;">
 <tbody> 

  <tr> <td style="width: 50%; text-align: center;"><b>Situs-Login</td> 
 <td style="width: 50%; text-align: center;"><b>btk-network.id</td> 
 </tr>
<tr> <td style="width: 50%; text-align: center;"><b>Speed</td> 
 <td style="width: 50%; text-align: center;"><b>Up To 5 Mbps</td> 
 </tr>
 <tr> <td style="width: 50%; text-align: center;"><b>Time Limit</td> 
 <td style="width: 50%; text-align: center;"><b><?php echo $timelimit;?></td> 
 </tr>

 <tr> 
 <td style="width: 50%; text-align: center;"><b>Validity</td>
 <td style="width: 50%; text-align: center;"><b><?php echo $validity;?></td> 
 </tr>
 </tbody>
 </table> 
 <table class="mikrotikindo" style="border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; width: 100%; margin-right: auto; margin-left: auto;"> 
 <tbody>
 <tr>
 <td style="width: 50%; text-align: center;">
 <span style="color: rgb(255, 255, 255); font-family: Tahoma;">Username</span></td>
 <td style="width: 50%; text-align: center;"><span style="color: rgb(255, 255, 255); font-family: Tahoma;"><b>Password</span>
 </td>
 </tr>
 <tr>
 <td style="background-color:#FFFFFF; width: 50%; text-align: center;">
 <span font-family: Tahoma; font-size: 16px;"><b><?= $username; ?></span>
 </td>
 <td style="background-color:#FFFFFF; width: 50%; text-align: center;">
 <span font-family: Tahoma; font-size: 16px;"><b><?= $password; ?></span>
 </td>
 </tr>
 </tbody>
 </table>
 <table class="mikrotikindo" style="border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; width: 100%; margin-right: auto; margin-left: auto;">
 <tbody>
 <tr>
 <td style="width: 40%; text-align: left;"><span style="color: rgb(255, 255, 255); font-family: Tahoma;">Contact :</span>
 </td>
 <td style="width: 60%; text-align: right;"><span style="color: rgb(255, 255, 255); font-family: Tahoma;">082333006683</span>
 </td>
 </tr>
 </tbody>
 </table>
 </td>
 <td style="background-color:#FFFFFF; width: 10px; text-align: center;">
 <div align="center" class="vertical-text" >Rp&nbsp;<?= explode(" ",$price)[1]?></div></td> </tr> </tbody>
<!-- Ini Akhir ROW -->